# piscine-go

Just for a revision. 😉