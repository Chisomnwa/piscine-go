#!/bin/bash

echo "hello world"

curl https://api.github.com/users/Chisomnwa